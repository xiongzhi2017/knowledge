# Java Standard

| Project | Description |
| -------- | -------- |
| [standard](https://vipshop.github.io/vjtools/#/standard/) | 唯品会Java开发手册 |
| [code formatter](formatter) | IDE格式化模板 |
| [sonar rule](sonar-vj) | Sonar规则定制示例 |
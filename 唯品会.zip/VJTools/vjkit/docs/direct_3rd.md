# 建议直接使用的第三方类


| Project | Class | 
|--- | --- |
|Common Lang | StringUtils |
| | Validate|
|Guava | Cache |
| | Ordering |
|JDK|Arrays|
| |Collections|

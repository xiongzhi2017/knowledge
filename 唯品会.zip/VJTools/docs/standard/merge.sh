#!/bin/sh

cat README.md > vip-java-standard.md
cat chapter01.md >> vip-java-standard.md
cat chapter02.md >> vip-java-standard.md
cat chapter03.md >> vip-java-standard.md
cat chapter04.md >> vip-java-standard.md
cat chapter05.md >> vip-java-standard.md
cat chapter06.md >> vip-java-standard.md
cat chapter07.md >> vip-java-standard.md
cat chapter08.md >> vip-java-standard.md
cat chapter09.md >> vip-java-standard.md
cat chapter10.md >> vip-java-standard.md
cat chapter11.md >> vip-java-standard.md
cat chapter12.md >> vip-java-standard.md
cat ali.md >> vip-java-standard.md

echo 'upload vip-java-standard.md to http://www.mdtr2pdf.com'


![VJTools](images/logo2.png)

- Standard
- Core Libraries
- Tools

[GitHub Project](https://github.com/vipshop/vjtools)
[Java Coding Guidelines](standard/)
